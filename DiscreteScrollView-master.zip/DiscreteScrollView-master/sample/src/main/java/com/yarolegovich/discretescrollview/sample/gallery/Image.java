package com.yarolegovich.discretescrollview.sample.gallery;

/**
 * Created by yarolegovich on 16.03.2017.
 */

public class Image {

    private final int res;

    public Image(int res) {
        this.res = res;
    }

    public int getResource() {
        return res;
    }
}
